(() => {
'use strict';
const modal=document.getElementById('game-modal'), close=document.getElementById('close-modal');
let current='racer',claimedThisRound=false;
const COIN_KEY='planetGeekCoinsV1';
let pgCoins=Math.max(0,Number(localStorage.getItem(COIN_KEY))||0);
const XP_KEY='planetGeekProgressV1', PROFILE_KEY='planetGeekProfileV1', RECORD_KEY='planetGeekRecordsV1', SHOP_KEY='planetGeekShopV1', MISSION_KEY='planetGeekDailyV1';
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
const write=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value))}catch{}}
let profile=read(PROFILE_KEY,{name:'Joueur Planet Geek'});
let xpState=read(XP_KEY,{xp:0,games:0,completed:[]});
let records=read(RECORD_KEY,{}), shop=read(SHOP_KEY,{owned:['default'],equipped:'default'}), missionState=read(MISSION_KEY,{});
if(!Array.isArray(xpState.completed))xpState.completed=[];
if(!Array.isArray(shop.owned))shop.owned=['default'];
const levelFor=xp=>Math.min(100,Math.floor(Math.sqrt(Math.max(0,xp)/100))+1);
const today=()=>new Date().toLocaleDateString('sv-SE');
const gameNames={gemtap:'Gem Tap',meteordodge:'Meteor Dodge',numberrush:'Number Rush',starcatcher:'Star Catcher',colormemory:'Color Memory',racer:'Neon Racer',jumper:'Pixel Jumper',blaster:'Star Blaster',memory:'Memory Matrix',mahjong:'Mahjong Neon',snake:'Snake Neon',ttt:'Tic Tac Toe',reaction:'Reflex Rush',pong:'Neon Pong',blocks:'Block Master',dino:'Dino Dash',flappy:'Flappy Rocket',bricks:'Brick Breaker',mole:'Critter Pop',invaders:'Space Invaders',math:'Math Sprint',color:'Color Tap',orbit:'Orbit Catch',cave:'Cave Explorer'};
const xpNow=()=>Math.max(0,Number(xpState.xp)||0);
const gamesNow=()=>Math.max(0,Number(xpState.games)||0);
function completionsToday(){return xpState.completed.filter(x=>x&&String(x.date||'').slice(0,10)===today());}
function renderXP(){
 const xp=xpNow(),games=gamesNow(),level=levelFor(xp),floor=(level-1)**2*100,next=level**2*100,progress=xp-floor,needed=next-floor;
 document.getElementById('pg-coins').textContent=pgCoins+' ◈';document.getElementById('xp-total').textContent=xp+' XP';document.getElementById('xp-level').textContent=level;document.getElementById('xp-games').textContent=games;
 document.getElementById('xp-next-label').textContent='Progression vers le niveau '+(level+1);document.getElementById('xp-progress-text').textContent=progress+' / '+needed+' XP';document.getElementById('xp-progress-fill').style.width=Math.min(100,progress/needed*100)+'%';
 const badges=badgeDefs().map(b=>`<span class="xp-badge ${b.ok?'unlocked':'locked'}">${b.ok?'✦ ':'🔒 '}${b.label}${b.ok?' ✓':''}</span>`);
 document.getElementById('xp-badges').innerHTML=badges.slice(0,5).join('');
 const name=(profile.name||'Joueur Planet Geek').trim()||'Joueur Planet Geek';document.getElementById('profile-name-display').textContent=name;document.getElementById('profile-avatar').textContent=name.split(/\s+/).slice(0,2).map(x=>x[0].toUpperCase()).join('')||'PG';document.getElementById('profile-level').textContent=level;document.getElementById('profile-xp').textContent=xp+' XP';
 renderMissions();renderShop();renderBadges();renderRecords();if(typeof renderExtras==='function')renderExtras();if(typeof renderSeasonPass==='function')renderSeasonPass();
}
function badgeDefs(){const xp=xpNow(),games=gamesNow(),level=levelFor(xp),todayCount=completionsToday().length;let mahjong={completed:[]};try{mahjong=JSON.parse(localStorage.getItem('planetGeekMahjongV2')||'{"completed":[]}')}catch{};const levels=Array.isArray(mahjong.completed)?mahjong.completed.length:0;return [
{id:'first',label:'Première partie',icon:'🎮',ok:games>=1},{id:'five',label:'5 parties',icon:'🕹️',ok:games>=5},{id:'ten',label:'10 parties',icon:'🏅',ok:games>=10},{id:'level5',label:'Niveau 5',icon:'🚀',ok:level>=5},{id:'xp500',label:'500 XP',icon:'💎',ok:xp>=500},{id:'daily3',label:'3 parties aujourd’hui',icon:'📅',ok:todayCount>=3},{id:'mahjong5',label:'5 niveaux de Mahjong',icon:'🀄',ok:levels>=5},{id:'shopper',label:'Premier achat',icon:'🛍️',ok:shop.owned.length>1},{id:'explorer',label:'10 jeux différents',icon:'🌌',ok:new Set(xpState.completed.map(x=>x.game)).size>=10},{id:'xp1000',label:'1000 XP',icon:'👑',ok:xp>=1000}
]}
function saveXP(){write(XP_KEY,xpState);renderXP();}
function claimXP(){if(claimedThisRound){document.getElementById('game-help').textContent='XP déjà récupérée pour cette partie !';return;}xpState.xp=xpNow()+10;pgCoins+=5;localStorage.setItem(COIN_KEY,String(pgCoins));xpState.games=gamesNow()+1;xpState.completed.push({game:current,date:new Date().toISOString()});records[current]=Math.max(0,Number(records[current])||0)+1;write(RECORD_KEY,records);if(ext.tournament&&ext.tournament.active&&ext.tournament.rounds<3){ext.tournament.rounds++;ext.tournament.score+=100; if(ext.tournament.rounds>=3)ext.tournament.active=false;write(EXT_KEY,ext);}claimedThisRound=true;saveXP();renderShop();renderExtras();renderWeeklyMissions();document.getElementById('claim-xp').disabled=true;document.getElementById('claim-xp').textContent='✓ XP RÉCUPÉRÉE';document.getElementById('game-help').textContent='+10 XP et +5 pièces PG ajoutés à ton profil !';}
function renderMissions(){
 const done=completionsToday(),playedReflection=done.some(x=>['memory','mahjong','ttt','blocks','math'].includes(x.game));
 const defs=[{id:'one',title:'Lance ta première partie',desc:'Valide 1 partie aujourd’hui',progress:Math.min(1,done.length),target:1,reward:15,ok:done.length>=1},{id:'three',title:'Session arcade',desc:'Valide 3 parties aujourd’hui',progress:Math.min(3,done.length),target:3,reward:30,ok:done.length>=3},{id:'think',title:'Fais travailler tes neurones',desc:'Valide une partie de réflexion',progress:playedReflection?1:0,target:1,reward:20,ok:playedReflection}];
 const claimed=missionState.date===today()&&Array.isArray(missionState.claimed)?missionState.claimed:[];
 document.getElementById('daily-missions').innerHTML=defs.map(m=>{const was=claimed.includes(m.id);return `<div class="mission-item"><div class="mission-copy"><strong>${m.title}</strong><small>${m.desc} · ${m.progress}/${m.target} · +${m.reward} XP</small><div class="mission-progress"><span style="width:${m.progress/m.target*100}%"></span></div></div><button data-mission="${m.id}" ${!m.ok||was?'disabled':''}>${was?'RÉCUPÉRÉ':m.ok?'RÉCLAMER':'EN COURS'}</button></div>`}).join('');
 document.querySelectorAll('[data-mission]').forEach(btn=>btn.addEventListener('click',()=>{const m=defs.find(x=>x.id===btn.dataset.mission);if(!m||!m.ok||claimed.includes(m.id))return;xpState.xp=xpNow()+m.reward;missionState={date:today(),claimed:[...claimed,m.id]};write(MISSION_KEY,missionState);saveXP();document.getElementById('mission-reset').textContent='Récompense récupérée : +'+m.reward+' XP !';}));
 document.getElementById('mission-reset').textContent='Nouvelles missions au changement de date locale. Termine une partie puis réclame la récompense ici.';
}
const shopItems=[{id:'default',name:'Cosmos classique',desc:'Thème original',cost:0},{id:'violet',name:'Nébuleuse violette',desc:'Accent violet et rose',cost:40},{id:'sunset',name:'Supernova',desc:'Accent orange et doré',cost:75},{id:'forest',name:'Émeraude',desc:'Accent vert lumineux',cost:100}];
function renderShop(){document.body.dataset.theme=shop.equipped||'default';document.getElementById('xp-shop').innerHTML=shopItems.map(it=>{const owned=shop.owned.includes(it.id),equipped=shop.equipped===it.id;return `<div class="shop-item ${owned?'owned':''}"><div><strong>${it.name}</strong><small>${it.desc} · ${it.cost} pièces PG</small></div><button data-shop="${it.id}" ${equipped?'disabled':(!owned&&pgCoins<it.cost?'disabled':'')}>${equipped?'ÉQUIPÉ':owned?'ÉQUIPER':'ACHETER'}</button></div>`}).join('');document.querySelectorAll('[data-shop]').forEach(btn=>btn.addEventListener('click',()=>{const it=shopItems.find(x=>x.id===btn.dataset.shop);if(!it)return;if(shop.owned.includes(it.id)){shop.equipped=it.id;write(SHOP_KEY,shop);renderXP();return;}if(pgCoins<it.cost)return;pgCoins-=it.cost;localStorage.setItem(COIN_KEY,String(pgCoins));shop.owned.push(it.id);shop.equipped=it.id;write(SHOP_KEY,shop);write(XP_KEY,xpState);renderXP();renderShop();document.getElementById('shop-message').textContent=it.name+' acheté avec des pièces PG !';}));}
function renderBadges(){document.getElementById('badge-collection').innerHTML=badgeDefs().map(b=>`<div class="collection-badge ${b.ok?'unlocked':''}" title="${b.ok?'Badge débloqué':'Badge verrouillé'}"><b>${b.ok?b.icon:'🔒'}</b>${b.label}</div>`).join('');}
function renderRecords(){const played=Object.entries(records).filter(([,n])=>Number(n)>0).sort((a,b)=>b[1]-a[1]);document.getElementById('personal-records').innerHTML=`<div class="record-item"><div><strong>XP totale gagnée</strong><small>Progression actuelle</small></div><b>${xpNow()} XP</b></div><div class="record-item"><div><strong>Parties validées</strong><small>Tous jeux confondus</small></div><b>${gamesNow()}</b></div>`+(played.length?played.map(([id,n])=>`<div class="record-item"><div><strong>${gameNames[id]||id}</strong><small>Parties validées sur ce jeu</small></div><b>${n}</b></div>`).join(''):'<div class="record-empty">Valide ta première partie pour commencer ton historique.</div>');}
function makeChallenge(){const payload={v:1,name:(profile.name||'Joueur').slice(0,18),xp:xpNow(),games:gamesNow(),date:today()};const code='PG1-'+btoa(unescape(encodeURIComponent(JSON.stringify(payload)))).replace(/=/g,'');document.getElementById('my-challenge').value=code;document.getElementById('challenge-result').textContent='Copie ce code et envoie-le à ton ami.';try{navigator.clipboard?.writeText(code).then(()=>{document.getElementById('challenge-result').textContent='Code copié ! Envoie-le à ton ami.'}).catch(()=>{})}catch{}}
function compareChallenge(){const raw=document.getElementById('challenge-code').value.trim();const out=document.getElementById('challenge-result');try{if(!raw.startsWith('PG1-'))throw Error();let encoded=raw.slice(4);encoded+='='.repeat((4-encoded.length%4)%4);const other=JSON.parse(decodeURIComponent(escape(atob(encoded))));if(other.v!==1||typeof other.xp!=='number'||typeof other.games!=='number')throw Error();const me={name:profile.name||'Toi',xp:xpNow(),games:gamesNow()};const wins=(me.xp>other.xp?1:0)+(me.games>other.games?1:0),losses=(me.xp<other.xp?1:0)+(me.games<other.games?1:0);out.textContent=`${me.name} : ${me.xp} XP, ${me.games} parties. ${other.name||'Ami'} : ${other.xp} XP, ${other.games} parties. `+(wins>losses?'Tu es devant !':wins<losses?'Ton ami est devant !':'Égalité !');}catch{out.textContent='Code invalide. Demande à ton ami de créer un nouveau code depuis son site.';}}
document.getElementById('profile-name').value=profile.name||'';
document.getElementById('profile-form').addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('profile-name').value.trim().replace(/\s+/g,' ');if(name.length<2)return;profile={name:name.slice(0,18)};write(PROFILE_KEY,profile);renderXP();document.getElementById('profile-name').value=profile.name;});
document.getElementById('make-challenge').addEventListener('click',makeChallenge);document.getElementById('compare-challenge').addEventListener('click',compareChallenge);
// Pass de saison : paliers gratuits basés sur les parties validées.
const SEASON_KEY='planetGeekSeasonPassV1';
let seasonState=read(SEASON_KEY,{claimed:[]});
const seasonTiers=[
 {id:1,need:1,reward:15,label:'Départ cosmique',icon:'🚀'},
 {id:2,need:3,reward:25,label:'Explorateur',icon:'🪐'},
 {id:3,need:5,reward:40,label:'Chasseur d’étoiles',icon:'🌟'},
 {id:4,need:8,reward:60,label:'Pilote galactique',icon:'🛸'},
 {id:5,need:12,reward:100,label:'Légende cosmique',icon:'👑'}
];
function renderSeasonPass(){
 const games=gamesNow(),next=seasonTiers.find(t=>games<t.need),tier=seasonTiers.filter(t=>games>=t.need).length;
 const current=next||seasonTiers[seasonTiers.length-1];
 document.getElementById('season-tier-label').textContent='Palier '+Math.min(5,tier+1)+' / 5';
 document.getElementById('season-progress-label').textContent=next?`${games} / ${next.need} parties validées`:'Pass terminé ! Toutes les étapes sont débloquées.';
 const previous=next?seasonTiers[seasonTiers.indexOf(next)-1]?.need||0:12;
 document.getElementById('season-progress-fill').style.width=next?Math.min(100,Math.max(0,(games-previous)/(next.need-previous)*100))+'%':'100%';
 document.getElementById('season-rewards').innerHTML=seasonTiers.map(t=>{const unlocked=games>=t.need,claimed=seasonState.claimed.includes(t.id);return `<article class="season-reward ${unlocked?'unlocked':''} ${claimed?'claimed':''}"><span class="season-reward-icon">${t.icon}</span><small>PALIER ${t.id}</small><b>${t.label}</b><strong>+${t.reward} XP</strong><button type="button" data-season-claim="${t.id}" ${!unlocked||claimed?'disabled':''}>${claimed?'RÉCUPÉRÉ':unlocked?'RÉCLAMER':'🔒 '+t.need+' parties'}</button></article>`}).join('');
 document.querySelectorAll('[data-season-claim]').forEach(btn=>btn.addEventListener('click',()=>{const t=seasonTiers.find(x=>x.id===Number(btn.dataset.seasonClaim));if(!t||gamesNow()<t.need||seasonState.claimed.includes(t.id))return;seasonState.claimed.push(t.id);xpState.xp=xpNow()+t.reward;write(SEASON_KEY,seasonState);write(XP_KEY,xpState);renderSeasonPass();renderXP();document.getElementById('season-status').textContent=`Récompense récupérée : +${t.reward} XP !`;}));
}

// Extensions de progression : toutes les données restent sauvegardées localement.
const EXT_KEY='planetGeekExtendedV1';
let ext=read(EXT_KEY,{chest:'',bossWeek:'',bossHP:5,tournament:null,companion:{level:1,energy:100,xp:0},skins:['pixel'],equippedSkin:'pixel',secretSeen:[]});
function saveExt(){write(EXT_KEY,ext);renderExtras();}
function weekKey(){const d=new Date();const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day+3);const first=new Date(d.getFullYear(),0,4);const week=1+Math.round(((d-first)/86400000-3+((first.getDay()+6)%7))/7);return d.getFullYear()+'-W'+String(week).padStart(2,'0');}
const rankDefs=[{name:'Bronze',xp:0},{name:'Argent',xp:250},{name:'Or',xp:600},{name:'Platine',xp:1200},{name:'Diamant',xp:2200},{name:'Légende',xp:4000}];
const skins=[{id:'pixel',name:'Pixel classique',icon:'🤖',cost:0},{id:'alien',name:'Alien néon',icon:'👽',cost:100},{id:'fox',name:'Renard cosmique',icon:'🦊',cost:220},{id:'dragon',name:'Dragon stellaire',icon:'🐉',cost:400},{id:'robot',name:'Robot doré',icon:'🦾',cost:650}];
function renderExtras(){
 const xp=xpNow(), rank=[...rankDefs].reverse().find(r=>xp>=r.xp)||rankDefs[0],idx=rankDefs.findIndex(r=>r.name===rank.name),next=rankDefs[idx+1];
 document.getElementById('rank-name').textContent=rank.name;document.getElementById('rank-fill').style.width=next?Math.min(100,(xp-rank.xp)/(next.xp-rank.xp)*100)+'%':'100%';document.getElementById('rank-desc').textContent=next?(xp-rank.xp)+' / '+(next.xp-rank.xp)+' XP vers '+next.name:'Rang maximum atteint !';
 document.getElementById('skin-inventory').innerHTML=skins.map(s=>{const own=ext.skins.includes(s.id),eq=ext.equippedSkin===s.id;return `<div class="skin-item"><span class="skin-icon">${s.icon}</span><b>${s.name}</b><small>${own?'Dans ton inventaire':s.cost+' XP'}</small><button data-skin="${s.id}" ${eq?'disabled':(!own&&xp<s.cost?'disabled':'')}>${eq?'ÉQUIPÉ':own?'ÉQUIPER':'ACHETER'}</button></div>`}).join('');
 document.querySelectorAll('[data-skin]').forEach(b=>b.addEventListener('click',()=>{const s=skins.find(x=>x.id===b.dataset.skin);if(!s)return;if(ext.skins.includes(s.id)){ext.equippedSkin=s.id;}else if(xpNow()>=s.cost){xpState.xp=xpNow()-s.cost;ext.skins.push(s.id);ext.equippedSkin=s.id;write(XP_KEY,xpState);}else return;saveExt();renderXP();}));
 const week=weekKey();if(ext.bossWeek!==week){ext.bossWeek=week;ext.bossHP=5;write(EXT_KEY,ext);}document.getElementById('boss-health-fill').style.width=(ext.bossHP/5*100)+'%';document.getElementById('boss-status').textContent=ext.bossHP>0?`Points de vie du boss : ${ext.bossHP}/5`:'Boss vaincu ! Récompense hebdomadaire récupérée.';document.getElementById('boss-hit').disabled=ext.bossHP<=0;
 const zones=[['Station de départ',0,'Disponible dès le début'],['Forêt pixel',3,'3 parties validées'],['Désert néon',8,'8 parties validées'],['Nébuleuse',15,'15 parties validées'],['Citadelle cosmique',25,'25 parties validées']];document.getElementById('world-map').innerHTML=zones.map(([n,g,d])=>`<div class="world-zone ${gamesNow()>=g?'unlocked':''}"><b>${gamesNow()>=g?'✦':'🔒'} ${n}</b><small>${gamesNow()>=g?'Zone débloquée':d}</small></div>`).join('');
 const opened=ext.chest===today();document.getElementById('daily-chest').disabled=opened;document.getElementById('daily-chest').textContent=opened?'Coffre déjà ouvert':'Ouvrir le coffre';document.getElementById('chest-status').textContent=opened?'Reviens demain pour un nouveau coffre.':'Un cadeau XP t’attend !';
 const t=ext.tournament||{rounds:0,score:0,claimed:false,active:false};document.getElementById('tournament-progress').textContent=`${Math.min(3,t.rounds)}/3 manches`;document.getElementById('tournament-score').textContent=`${t.score} points`;document.getElementById('tournament-claim').disabled=!(t.rounds>=3&&!t.claimed);document.getElementById('tournament-status').textContent=t.claimed?'Récompense du tournoi déjà récupérée.':t.rounds>=3?'Tournoi terminé ! Réclame tes 50 XP.':'Joue à des mini-jeux puis valide les parties pour avancer.';
 const c=ext.companion||{level:1,energy:100,xp:0};document.getElementById('companion-face').textContent=skins.find(s=>s.id===ext.equippedSkin)?.icon||'🤖';document.getElementById('companion-level').textContent=`Niveau ${c.level} · énergie ${c.energy}%`;document.getElementById('companion-feed').disabled=xpNow()<20||c.energy>=100;document.getElementById('companion-status').textContent=c.energy>=100?'Ton compagnon est en pleine forme !':'Il a besoin d’un peu d’énergie.';
 const secrets=[{id:'many',name:'Secret : explorateur',ok:new Set(xpState.completed.map(x=>x.game)).size>=5,desc:'Jouer à 5 jeux différents'},{id:'night',name:'Secret : collectionneur',ok:ext.skins.length>=3,desc:'Posséder 3 skins'},{id:'rich',name:'Secret : trésor cosmique',ok:xpNow()>=1000,desc:'Atteindre 1000 XP'},{id:'boss',name:'Secret : chasseur de boss',ok:ext.bossHP===0,desc:'Vaincre le boss hebdomadaire'}];document.getElementById('secret-achievements').innerHTML=secrets.map(s=>`<div class="secret-item ${s.ok?'unlocked':''}">${s.ok?'✦':'???'} ${s.ok?s.name:'Succès mystérieux'}<small style="display:block">${s.ok?s.desc:'Continue à explorer pour le découvrir.'}</small></div>`).join('');
 // Statistiques additionnelles basées uniquement sur les données disponibles.
 const daily=completionsToday().length,distinct=new Set(xpState.completed.map(x=>x.game)).size,streak=(()=>{let n=0,d=new Date();const dates=new Set(xpState.completed.map(x=>String(x.date||'').slice(0,10)));while(dates.has(d.toLocaleDateString('sv-SE'))){n++;d.setDate(d.getDate()-1)}return n})();
 const recordsEl=document.getElementById('personal-records');if(!document.getElementById('extended-stats')){const div=document.createElement('div');div.id='extended-stats';div.className='record-item';recordsEl.appendChild(div);}document.getElementById('extended-stats').innerHTML=`<div><strong>Statistiques détaillées</strong><small>${distinct} jeux différents · ${daily} parties aujourd’hui · série actuelle : ${streak} jour(s)</small></div><b>${Math.round(xpNow()/Math.max(1,gamesNow()))} XP/partie</b>`;
}
document.getElementById('boss-hit').addEventListener('click',()=>{if(ext.bossHP<=0)return;ext.bossHP--;if(ext.bossHP===0){xpState.xp=xpNow()+75;write(XP_KEY,xpState);document.getElementById('boss-status').textContent='Boss vaincu ! +75 XP';}saveExt();renderXP();});
document.getElementById('daily-chest').addEventListener('click',()=>{if(ext.chest===today())return;const reward=25+Math.floor(Math.random()*26);ext.chest=today();xpState.xp=xpNow()+reward;write(XP_KEY,xpState);saveExt();renderXP();document.getElementById('chest-status').textContent=`Coffre ouvert : +${reward} XP !`;});
document.getElementById('tournament-start').addEventListener('click',()=>{ext.tournament={rounds:0,score:0,claimed:false,active:true,baseline:gamesNow()};saveExt();});
document.getElementById('tournament-claim').addEventListener('click',()=>{const t=ext.tournament;if(!t||t.rounds<3||t.claimed)return;xpState.xp=xpNow()+50;t.claimed=true;write(XP_KEY,xpState);saveExt();renderXP();});
document.getElementById('companion-feed').addEventListener('click',()=>{const c=ext.companion;if(xpNow()<20||c.energy>=100)return;xpState.xp=xpNow()-20;c.energy=Math.min(100,c.energy+25);c.xp+=25;if(c.xp>=100){c.level++;c.xp-=100;}write(XP_KEY,xpState);saveExt();renderXP();});

renderExtras();
renderSeasonPass();
renderXP();
function openGame(game){current=game;claimedThisRound=false;window.currentGame=game;document.getElementById('claim-xp').disabled=false;document.getElementById('claim-xp').textContent='✓ TERMINER LA PARTIE · +10 XP';modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';PlanetGames.launch(game);}
function shut(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');document.body.style.overflow='';document.getElementById('game-host').innerHTML='';}
document.querySelectorAll('[data-game]').forEach(b=>b.addEventListener('click',()=>openGame(b.dataset.game)));
document.getElementById('claim-xp').addEventListener('click',claimXP);
close.addEventListener('click',shut);modal.addEventListener('click',e=>{if(e.target===modal)shut();});document.addEventListener('keydown',e=>{if(e.key==='Escape')shut();});document.getElementById('restart-game').addEventListener('click',()=>{window.currentGame=current;PlanetGames.launch(current);});
const search=document.getElementById('search'),clearSearch=document.getElementById('clear-search'),filters=[...document.querySelectorAll('.filter')],cards=[...document.querySelectorAll('.game-card')];let category='Tous';
const normalizeSearch=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('fr').trim();
function update(){const q=normalizeSearch(search.value);let visible=0;cards.forEach(c=>{const searchable=normalizeSearch([c.dataset.name,c.dataset.category,c.querySelector('h3')?.textContent,c.querySelector('.game-info p')?.textContent,c.querySelector('.cover-label')?.textContent].filter(Boolean).join(' '));const ok=(category==='Tous'||c.dataset.category===category)&&searchable.includes(q);c.hidden=!ok;if(ok)visible++;});document.getElementById('visible-count').textContent=visible;document.getElementById('empty').hidden=visible!==0;clearSearch.hidden=!search.value;}
search.addEventListener('input',update);clearSearch.addEventListener('click',()=>{search.value='';update();search.focus();});search.addEventListener('keydown',e=>{if(e.key==='Escape'){if(search.value){search.value='';update();e.stopPropagation();}}else if(e.key==='Enter'){const first=cards.find(c=>!c.hidden);if(first){first.scrollIntoView({behavior:'smooth',block:'center'});first.querySelector('[data-game]')?.focus({preventScroll:true});}}});filters.forEach(b=>b.addEventListener('click',()=>{filters.forEach(f=>f.classList.toggle('active',f===b));category=b.dataset.category;update();}));document.getElementById('year').textContent=new Date().getFullYear();update();

/* Défis hebdomadaires intégrés à la progression principale */
function renderWeeklyMissions(){
 const host=document.getElementById('weekly-missions'); if(!host)return;
 const d=new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()-((d.getDay()+6)%7));
 const week=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
 let state=read('planetGeekWeeklyV1',{week,claimed:[]}); if(state.week!==week)state={week,claimed:[]};
 const done=(xpState.completed||[]).filter(x=>{const t=new Date(x.date);return !Number.isNaN(t.getTime())&&t>=d;});
 const unique=new Set(done.map(x=>x.game)).size;
 const defs=[{id:'games5',title:'Série de la semaine',desc:'Valide 5 parties cette semaine',n:done.length,target:5,xp:60,coins:20},{id:'variety3',title:'Touche-à-tout',desc:'Essaie 3 jeux différents',n:unique,target:3,xp:45,coins:15},{id:'games12',title:'Marathon galactique',desc:'Valide 12 parties cette semaine',n:done.length,target:12,xp:100,coins:35}];
 host.innerHTML=defs.map(m=>{const claimed=state.claimed.includes(m.id),ready=m.n>=m.target;return `<div class="mission-item"><div class="mission-copy"><strong>${m.title}</strong><small>${m.desc} · ${Math.min(m.n,m.target)}/${m.target} · +${m.xp} XP et +${m.coins} pièces</small><div class="mission-progress"><span style="width:${Math.min(100,m.n/m.target*100)}%"></span></div></div><button type="button" data-weekly-claim="${m.id}" ${!ready||claimed?'disabled':''}>${claimed?'RÉCUPÉRÉ':ready?'RÉCLAMER':'EN COURS'}</button></div>`}).join('');
 const status=document.getElementById('weekly-status'); if(status)status.textContent='Les défis se renouvellent chaque lundi. Progression sauvegardée sur cet appareil.';
 host.querySelectorAll('[data-weekly-claim]').forEach(b=>b.addEventListener('click',()=>{const m=defs.find(x=>x.id===b.dataset.weeklyClaim);if(!m||m.n<m.target||state.claimed.includes(m.id))return;xpState.xp=xpNow()+m.xp;pgCoins+=m.coins;localStorage.setItem(COIN_KEY,String(pgCoins));state.claimed.push(m.id);write('planetGeekWeeklyV1',state);saveXP();renderShop();renderExtras();renderWeeklyMissions();if(status)status.textContent=`Défi terminé : +${m.xp} XP et +${m.coins} pièces PG !`;}));
}
renderWeeklyMissions();

})();

/* Boutique cosmétique + mini-arène Planet Arena */
(()=>{'use strict';
const KEY='planetGeekProgressV1', INV='planetGeekArenaInventoryV1';
const read=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const items=[
{id:'pixel',name:'Explorateur Pixel',kind:'Skin',price:0,icon:'🧑‍🚀',color:'#42e8ff',desc:'Le look de départ.'},
{id:'nova',name:'Nova électrique',kind:'Skin',price:80,icon:'⚡',color:'#b56bff',desc:'Une aura violette.'},
{id:'flame',name:'Combattant flamme',kind:'Skin',price:140,icon:'🔥',color:'#ff784f',desc:'Un style ardent.'},
{id:'dance',name:'Emote Robot',kind:'Danse',price:60,icon:'🤖',color:'#69f0c1',desc:'Une danse mécanique.'},
{id:'disco',name:'Emote Disco',kind:'Danse',price:100,icon:'🪩',color:'#ff72d2',desc:'Fais briller l’arène.'},
{id:'beat',name:'Beat cosmique',kind:'Musique',price:90,icon:'🎵',color:'#ffcf66',desc:'Un motif musical généré dans le navigateur.'},
{id:'trail',name:'Traînée étoilée',kind:'Accessoire',price:120,icon:'✨',color:'#fff19a',desc:'Des étoiles quand tu bouges.'}
];
let inv=read(INV,{owned:['pixel'],equipped:'pixel',emote:'dance',music:'beat'}); if(!inv.owned.includes('pixel'))inv.owned.unshift('pixel');
const progress=()=>read(KEY,{xp:0,games:0,completed:[]});
function render(){const p=progress();document.getElementById('pg-store-balance').textContent=`✦ ${Number(p.xp)||0} XP disponibles`;const lx=document.getElementById('lobby-xp');if(lx)lx.textContent=`${Number(p.xp)||0} XP`;const currentSkin=items.find(x=>x.id===inv.equipped)||items[0];const li=document.getElementById('lobby-avatar-icon');if(li)li.textContent=currentSkin.icon;const ln=document.getElementById('lobby-skin-name');if(ln)ln.textContent=currentSkin.name;document.getElementById('pg-store-items').innerHTML=items.map(it=>{const owned=inv.owned.includes(it.id),equipped=inv.equipped===it.id||inv.emote===it.id||inv.music===it.id;return `<article class="pg-store-card"><div class="pg-item-icon" style="--item-color:${it.color}">${it.icon}</div><small>${it.kind.toUpperCase()}</small><h3>${it.name}</h3><p>${it.desc}</p><strong>${it.price?it.price+' XP':'GRATUIT'}</strong><button type="button" data-pg-item="${it.id}">${owned?(equipped?'ÉQUIPÉ':'ÉQUIPER'):'ACHETER'}</button></article>`}).join('');document.querySelectorAll('[data-pg-item]').forEach(b=>b.addEventListener('click',()=>buy(b.dataset.pgItem)));document.getElementById('pg-arena-skin').textContent='Skin : '+(items.find(x=>x.id===inv.equipped)?.name||'Explorateur Pixel');const locker=document.getElementById('pg-locker-items');if(locker){const ownedItems=items.filter(it=>inv.owned.includes(it.id));locker.innerHTML=ownedItems.map(it=>{const equipped=inv.equipped===it.id||inv.emote===it.id||inv.music===it.id;return `<article class="pg-store-card pg-locker-card"><div class="pg-item-icon" style="--item-color:${it.color}">${it.icon}</div><small>${it.kind.toUpperCase()}</small><h3>${it.name}</h3><span class="owned-label">✓ POSSÉDÉ</span><button type="button" data-pg-equip="${it.id}" ${equipped?'disabled':''}>${equipped?'ÉQUIPÉ':'ÉQUIPER'}</button></article>`}).join('')||'<p>Aucun objet pour le moment.</p>';locker.querySelectorAll('[data-pg-equip]').forEach(b=>b.addEventListener('click',()=>{const it=items.find(z=>z.id===b.dataset.pgEquip);if(!it)return;if(it.kind==='Skin')inv.equipped=it.id;else if(it.kind==='Danse')inv.emote=it.id;else if(it.kind==='Musique')inv.music=it.id;write(INV,inv);document.getElementById('pg-locker-status').textContent=it.name+' équipé !';render();}));}draw();}
function buy(id){const it=items.find(x=>x.id===id);if(!it)return;let p=progress();if(!inv.owned.includes(id)){if((Number(p.xp)||0)<it.price){document.getElementById('pg-store-status').textContent='Pas assez d’XP pour cet objet. Joue à des mini-jeux pour en gagner !';return;}p.xp-=it.price;write(KEY,p);inv.owned.push(id);document.getElementById('pg-store-status').textContent=`${it.name} acheté !`;}if(it.kind==='Skin')inv.equipped=id;else if(it.kind==='Danse')inv.emote=id;else if(it.kind==='Musique')inv.music=id;write(INV,inv);render();}
const canvas=document.getElementById('pg-arena'),ctx=canvas.getContext('2d');let x=450,y=220,keys={},danceUntil=0,musicOn=false,audio=null,step=0,botMode=false,botX=220,botY=180;
function draw(){if(!ctx)return;const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#0a2340');g.addColorStop(1,'#160d2c');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);ctx.strokeStyle='#42e8ff22';ctx.lineWidth=1;for(let i=0;i<w;i+=45){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,h);ctx.stroke()}for(let j=0;j<h;j+=45){ctx.beginPath();ctx.moveTo(0,j);ctx.lineTo(w,j);ctx.stroke()}for(let i=0;i<18;i++){let sx=(i*137+step*0.3)%w,sy=(i*71)%h;ctx.fillStyle='#9cecff88';ctx.fillRect(sx,sy,3,3)}ctx.fillStyle='#42e8ff18';ctx.beginPath();ctx.ellipse(450,225,250,120,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#42e8ff66';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(450,225,250,120,0,0,Math.PI*2);ctx.stroke();const it=items.find(a=>a.id===inv.equipped)||items[0];ctx.save();ctx.translate(x,y);if(Date.now()<danceUntil)ctx.rotate(Math.sin(Date.now()/80)*.35);ctx.shadowBlur=24;ctx.shadowColor=it.color;ctx.fillStyle=it.color;ctx.beginPath();ctx.arc(0,0,22,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#061323';ctx.beginPath();ctx.arc(-7,-4,3,0,Math.PI*2);ctx.arc(7,-4,3,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#061323';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,3,8,0,Math.PI);ctx.stroke();ctx.restore();if(botMode){botX+=Math.sign(x-botX)*0.65;botY+=Math.sign(y-botY)*0.45;ctx.fillStyle='#ff668a';ctx.shadowBlur=18;ctx.shadowColor='#ff668a';ctx.beginPath();ctx.arc(botX,botY,19,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#2b0920';ctx.fillRect(botX-7,botY-4,4,4);ctx.fillRect(botX+4,botY-4,4,4);ctx.fillStyle='#ffd8e1';ctx.font='bold 13px sans-serif';ctx.fillText('BOT',botX,botY-30);if(Math.hypot(x-botX,y-botY)<34){ctx.fillStyle='#ffcf66';ctx.font='bold 16px sans-serif';ctx.fillText('PROCHE DU BOT !',450,35);}}ctx.fillStyle='#e7f9ff';ctx.font='bold 14px sans-serif';ctx.textAlign='center';ctx.fillText('TOI',x,y-34);if(Date.now()<danceUntil){ctx.font='30px sans-serif';ctx.fillText(items.find(a=>a.id===inv.emote)?.icon||'💃',x,y-55)}}
function loop(){let dx=0,dy=0;if(keys.ArrowLeft||keys.a||keys.A)dx--;if(keys.ArrowRight||keys.d||keys.D)dx++;if(keys.ArrowUp||keys.w||keys.W)dy--;if(keys.ArrowDown||keys.s||keys.S)dy++;if(dx||dy){const n=Math.hypot(dx,dy)||1;x=Math.max(25,Math.min(canvas.width-25,x+dx/n*3.5));y=Math.max(35,Math.min(canvas.height-25,y+dy/n*3.5));step++;}draw();requestAnimationFrame(loop)}
window.addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)&&document.activeElement===document.body)e.preventDefault();keys[e.key]=true});window.addEventListener('keyup',e=>keys[e.key]=false);document.querySelectorAll('[data-move]').forEach(b=>{const k={up:'ArrowUp',down:'ArrowDown',left:'ArrowLeft',right:'ArrowRight'}[b.dataset.move];b.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true});['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>keys[k]=false))});
document.getElementById('pg-emote').addEventListener('click',()=>{if(!inv.owned.includes(inv.emote)){document.getElementById('pg-arena-emote').textContent='Achète une danse dans la boutique pour l’utiliser.';return;}danceUntil=Date.now()+2500;document.getElementById('pg-arena-emote').textContent='Emote : '+(items.find(a=>a.id===inv.emote)?.name||'Danse')+' !';});
document.getElementById('pg-reset-player').addEventListener('click',()=>{x=450;y=220;botX=220;botY=180;document.getElementById('pg-arena-emote').textContent='Position recentrée.'});document.getElementById('pg-bot-mode').addEventListener('click',()=>{botMode=!botMode;document.getElementById('pg-bot-mode').textContent='🤖 Défi contre bot : '+(botMode?'ON':'OFF');document.getElementById('pg-arena-emote').textContent=botMode?'Bot activé : approche-toi pour le défier.':'Mode exploration activé.';});
document.getElementById('pg-music').addEventListener('click',()=>{try{if(!musicOn){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw Error();audio=new AC();let osc=audio.createOscillator(),gain=audio.createGain();osc.type='triangle';osc.frequency.value=220;gain.gain.value=.025;osc.connect(gain);gain.connect(audio.destination);osc.start();musicOn=true;document.getElementById('pg-music').textContent='♫ Couper la musique';document.getElementById('pg-arena-emote').textContent='Musique originale activée.';}else{audio?.close();audio=null;musicOn=false;document.getElementById('pg-music').textContent='♫ Musique : activer';}}catch{document.getElementById('pg-arena-emote').textContent='Audio non disponible sur ce navigateur.'}});
window.addEventListener('storage',e=>{if(e.key===KEY)render()});render();loop();
})();


// Compte à rebours commun : une saison dure 30 jours à partir de cette date de référence.
(function initSeasonCountdown(){
 const output=document.getElementById('season-countdown');
 if(!output)return;
 const SEASON_LENGTH=30*24*60*60*1000;
 const SEASON_ANCHOR=Date.UTC(2026,9,21,0,0,0);
 function update(){
  const now=Date.now();
  const elapsed=Math.max(0,now-SEASON_ANCHOR);
  const next=SEASON_ANCHOR+(Math.floor(elapsed/SEASON_LENGTH)+1)*SEASON_LENGTH;
  let remaining=Math.max(0,next-now);
  const days=Math.floor(remaining/86400000);remaining%=86400000;
  const hours=Math.floor(remaining/3600000);remaining%=3600000;
  const minutes=Math.floor(remaining/60000);remaining%=60000;
  const seconds=Math.floor(remaining/1000);
  output.textContent=`${days} j ${String(hours).padStart(2,'0')} h ${String(minutes).padStart(2,'0')} min ${String(seconds).padStart(2,'0')} s`;
 }
 update();setInterval(update,1000);
})();
